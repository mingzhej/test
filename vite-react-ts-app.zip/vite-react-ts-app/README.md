# Vite+React+TypeScript+TailwindCSS App

This project is a React application bootstrapped with [Vite](https://vitejs.dev/), TypeScript and [TailwindCSS](https://tailwindcss.com/).

## Features

- Fetches and displays posts from an API
- Post filtering with debounce search
- User selection dropdown for filtering
- WCAG Compliance with keyboard navigation: `Tab` / `Shift+Tab` to navigate, `Enter` to open and `ESC` to close
- Custom React hooks

## Getting Started

1. **Install dependencies:**

   ```
   npm install
   ```

2. **Set up environment variables:**

   Create a `.env` file in the project root:

   ```
   VITE_API_URL=https://your-api-url.com
   ```

3. **Run the development server:**

   ```
   npm run dev
   ```

4. **Build for production:**
   ```
   npm run build
   ```

## Project Structure

- `src/components/` – React components (e.g., `PostFilter.tsx`)
- `src/hooks/` – Custom React hooks (e.g., `usePosts.ts`)
- `src/types/` – TypeScript type definitions

## License

MIT
