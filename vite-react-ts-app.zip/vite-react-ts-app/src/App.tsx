import { useState, useMemo, useEffect, useRef } from "react";
import { usePosts } from "@/hooks/usePosts";
import PostCard from "@/components/PostCard";
import PostDetail from "@/components/PostDetail";
import PostFilter from "@/components/PostFilter";
import Loader from "@/components/Loader";
import Error from "@/components/Error";
import type { Post } from "@/types/post";

export default function App() {
  const { posts, loading, error } = usePosts();
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedUserId, setSelectedUserId] = useState<string>("");

  // Extract unique userIds from posts
  const userIds = useMemo(() => {
    const ids = new Set<number>();
    posts.forEach((post) => ids.add(post.userId));
    return Array.from(ids).sort((a, b) => a - b);
  }, [posts]);

  // Filter posts based on search and userId
  const filteredPosts = useMemo(() => {
    return posts.filter((post) => {
      const matchesUser =
        selectedUserId === "" || post.userId === Number(selectedUserId);
      const matchesSearch =
        post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        post.body.toLowerCase().includes(searchTerm.toLowerCase());
      return matchesUser && matchesSearch;
    });
  }, [posts, searchTerm, selectedUserId]);

  // Ref for modal to handle clicks outside
  // to close the modal when clicking outside of it
  const modalRef = useRef<HTMLDivElement>(null);

  // Ref to store the last focused post element
  const lastFocusedPostRef = useRef<HTMLDivElement | null>(null);

  // When opening modal, store the focused element
  const handleOpenPost = (
    post: Post,
    event?: React.KeyboardEvent | React.MouseEvent
  ) => {
    if (event && event.currentTarget instanceof HTMLDivElement) {
      lastFocusedPostRef.current = event.currentTarget;
    }
    setSelectedPost(post);
  };

  // Restore focus to the last focused post when modal closes
  useEffect(() => {
    if (!selectedPost && lastFocusedPostRef.current) {
      lastFocusedPostRef.current.focus();
    }
  }, [selectedPost]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        modalRef.current &&
        !modalRef.current.contains(event.target as Node)
      ) {
        setSelectedPost(null);
      }
    };

    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setSelectedPost(null);
      }
    };

    if (selectedPost) {
      document.addEventListener("mousedown", handleClickOutside);
      document.addEventListener("keydown", handleEsc);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleEsc);
    };
  }, [selectedPost]);

  if (loading) return <Loader />;
  if (error) return <Error message={error} />;

  return (
    <div className="max-w-3xl mx-auto p-4">
      <h1 className="text-3xl font-bold text-center mt-5">Social Feed</h1>
      <div className="text-center text-gray-700 mb-6 ">
        Discover and explore amazing posts from our community
      </div>
      <>
        <PostFilter
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          selectedUserId={selectedUserId}
          setSelectedUserId={setSelectedUserId}
          userIds={userIds}
        />

        {filteredPosts.length === 0 ? (
          <div className="text-gray-500 text-center">No posts found.</div>
        ) : (
          <div className="grid gap-4">
            {filteredPosts.map((post) => (
              <div
                key={post.id}
                tabIndex={0} // Make it focusable for keyboard navigation
                role="button"
                aria-label={`Open post titled ${post.title}`}
                onClick={(e) => handleOpenPost(post, e)}
                onKeyDown={(e) => {
                  // Handle keyboard navigation for accessibility
                  if (e.key === "Enter") {
                    handleOpenPost(post, e);
                  }
                }}
                className="outline-none focus:ring-2 focus:ring-blue-500 rounded"
              >
                <PostCard post={post} />
              </div>
            ))}
          </div>
        )}

        {/* Modal for Post Detail */}
        {selectedPost && (
          <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
            <div
              ref={modalRef}
              className="bg-white rounded-lg shadow-lg max-w-xl w-full p-6 relative"
            >
              <button
                className="absolute top-2 right-2 text-gray-500 hover:text-black text-xl cursor-pointer"
                onClick={() => setSelectedPost(null)}
              >
                ×
              </button>
              <PostDetail post={selectedPost} />
            </div>
          </div>
        )}
      </>
    </div>
  );
}
