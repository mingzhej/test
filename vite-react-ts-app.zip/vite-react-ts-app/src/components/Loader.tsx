export default function Loader() {
  return <div className="text-center p-8 text-gray-500">Loading...</div>;
}
