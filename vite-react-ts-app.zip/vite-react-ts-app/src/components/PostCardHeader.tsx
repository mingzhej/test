import type { Post } from "@/types/post";

interface Props {
  post: Post;
}

// Predefine the full Tailwind class for each color
const userColors = [
  "bg-blue-600",
  "bg-green-600",
  "bg-red-600",
  "bg-purple-600",
  "bg-pink-600",
  "bg-yellow-600",
  "bg-indigo-600",
  "bg-teal-600",
  "bg-orange-600",
  "bg-rose-600",
];

export default function PostCardHeader({ post }: Props) {
  const colorClass = userColors[(post.userId - 1) % userColors.length];
  return (
    <div className="flex items-center gap-2 mb-2">
      <div
        className={`w-8 h-8 ${colorClass} text-white flex items-center justify-center rounded-full text-sm font-semibold`}
      >
        U{post.userId}
      </div>
      <span className="text-sm text-gray-700 font-bold">
        User {post.userId}
      </span>
      <span className="text-xs text-gray-700 font-medium bg-gray-200 px-3 py-1 rounded-full">
        ID: {post.id}
      </span>
    </div>
  );
}
