import type { Post } from "@/types/post";
import PostCardHeader from "@/components/PostCardHeader";

interface Props {
  post: Post;
}

export default function PostDetail({ post }: Props) {
  return (
    <div className="pt-2 bg-white">
      <PostCardHeader post={post} />
      <h2 className="text-2xl font-bold mb-2">{post.title}</h2>
      <p className="text-gray-700">{post.body}</p>
    </div>
  );
}
