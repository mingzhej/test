import type { Post } from "@/types/post";
import PostCardHeader from "@/components/PostCardHeader";

interface Props {
  post: Post;
}

export default function PostCard({ post }: Props) {
  return (
    <div className="p-4 border border-gray-300 rounded-lg shadow hover:bg-gray-50 cursor-pointer">
      <PostCardHeader post={post} />{" "}
      <h2 className="text-xl font-semibold">{post.title}</h2>
      <p className="text-gray-600 line-clamp-2">{post.body}</p>
    </div>
  );
}
