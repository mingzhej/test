import { useState, useEffect } from "react";

interface Props {
  searchTerm: string;
  setSearchTerm: (value: string) => void;
  selectedUserId: string;
  setSelectedUserId: (value: string) => void;
  userIds: number[];
}

// PostFilter component for filtering posts by search term and user
// This component includes a search input for post titles and content, and a select dropdown for filtering by user ID.
export default function PostFilter({
  searchTerm,
  setSearchTerm,
  selectedUserId,
  setSelectedUserId,
  userIds,
}: Props) {
  // Using local state to manage the search input value
  // This state is used to manage the input value locally before updating the global search term
  const [localSearch, setLocalSearch] = useState(searchTerm);

  useEffect(() => {
    const handler = setTimeout(() => {
      setSearchTerm(localSearch);
    }, 400); // 400ms debounce

    return () => clearTimeout(handler);
  }, [localSearch, setSearchTerm]);

  useEffect(() => {
    setLocalSearch(searchTerm);
  }, [searchTerm]);

  return (
    <div className="mb-4 p-4 border border-gray-300 rounded-lg shadow-sm bg-white">
      <div className="flex flex-col sm:flex-row items-center justify-start space-y-2 sm:space-y-0 sm:space-x-2">
        {/* Search input */}
        <div className="relative w-full sm:w-[65%]">
          <span className="absolute inset-y-0 left-3 flex items-center text-gray-400">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="w-4 h-4 text-gray-400"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M21 21l-4.35-4.35M11 18a7 7 0 1 1 0-14 7 7 0 0 1 0 14z"
              />
            </svg>
          </span>
          <input
            type="text"
            placeholder="Search posts by title or content..."
            className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded"
            value={localSearch}
            onChange={(e) => setLocalSearch(e.target.value)}
          />
        </div>
        {/* User select */}
        <div className="relative w-full sm:w-[35%]">
          <span className="absolute inset-y-0 left-3 flex items-center text-gray-400">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="w-4 h-4 text-gray-500"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M3 4a1 1 0 011-1h16a1 1 0 01.8 1.6L15 12.3V19a1 1 0 01-1.447.894l-4-2A1 1 0 019 17v-4.7L3.2 5.6A1 1 0 013 4z"
              />
            </svg>
          </span>
          <select
            value={selectedUserId}
            onChange={(e) => setSelectedUserId(e.target.value)}
            className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded"
          >
            <option value="">All Users</option>
            {userIds.map((id) => (
              <option key={id} value={id}>
                User {id}
              </option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
}
