interface Props {
  message: string;
}

export default function Error({ message }: Props) {
  return <div className="text-red-500 text-center p-8">{message}</div>;
}
